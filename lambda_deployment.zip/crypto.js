const fetch = require('node-fetch');
const BTC = '37VhBhZGbmFAgHZJunHVc6HNRBbtFEUbCf';
const ETH = '0x9b941d7ae9a9b4cdf0b821105ccb0feaf10a8de1';

const BTC_URL = 'https://blockchain.info/rawaddr/'
const ETH_URL = 'https://api.blockcypher.com/v1/eth/main/addrs/'

fetch(ETH_URL + ETH)
    .then((response) => {
        return response.json()
    })
    .then((data) => {
        console.log(data);
    })
    .catch(err => {
        console.log(err);
    })

